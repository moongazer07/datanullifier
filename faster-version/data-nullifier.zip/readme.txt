data nullifier is an app that lets you destroy your files securely by encrypting them with a very long password
you dont get a warning when executing the unextracted exe which the reason a winrar sfx is used
as a safety measure
if you are sent this program or get it from somewhere else it unoficially it could be tainted with malware
so get this from github and this is freeware
do not use this for malicious purposes
it also destroys network drive files so if you dont want to destroy those turn off your internet connection
i am not liable for any damages that are the result of misuse, malicious use, etc


.-moongazer07